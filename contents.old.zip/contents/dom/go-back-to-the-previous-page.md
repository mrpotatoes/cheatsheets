---
layout: post.njk
title: Go back to the previous page
category: DOM
---

**JavaScript version**

```js
history.back();

// Or
history.go(-1);
```

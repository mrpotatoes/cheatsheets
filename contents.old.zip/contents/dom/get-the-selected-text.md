---
layout: post.njk
title: Get the selected text
category: DOM
---

**JavaScript version**

```js
const getSelectedText = () => window.getSelection().toString();
```

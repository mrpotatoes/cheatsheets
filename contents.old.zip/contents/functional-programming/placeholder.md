---
layout: post.njk
title: Placeholder
category: Functional Programming
---

Not code but rahter types & cool TS specific tricks

## Things I need to put in here
- 

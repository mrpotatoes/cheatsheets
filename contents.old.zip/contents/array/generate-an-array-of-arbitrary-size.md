---
layout: post.njk
title: Generate an array of arbitrary size
category: Array
---

## JavaScript version

```js
Array.from(Array(10).keys())
```

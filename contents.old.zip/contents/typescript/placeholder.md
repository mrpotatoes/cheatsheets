---
layout: post.njk
title: Placeholder
category: TypeScript
---

Placeholder

Not code but rahter types & cool TS specific tricks

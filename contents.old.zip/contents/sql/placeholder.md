---
layout: post.njk
title: Placeholder
category: SQL
---

# Placeholder
```sql
SELECT *
FROM <TABLE>
WHERE <CLAUSE>
LIMIT 10
```

---
layout: post.njk
title: Identity function
category: Function
---

**JavaScript version**

```js
const identity = (x) => x;
```

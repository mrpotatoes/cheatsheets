---
layout: post.njk
title: find-ext
category: Dotfiles
---

# `find-ext`

Old, will delete in the future.

```
NAME
    file-ext -- Change the extension for a file.
SYNOPSIS
    file-ext [--help] [databse] [file] application-name
EXAMPLES
    file-ext root files files
    file-ext root files files.hey
      
SEE ALSO
    mysqldump
AUTHOR
  Andric Villanueva
COPYRIGHT
  MIT
```

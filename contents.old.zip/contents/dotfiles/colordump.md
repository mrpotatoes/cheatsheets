---
layout: post.njk
title: colordump
category: Dotfiles
---

# `argv`
Don't use me.

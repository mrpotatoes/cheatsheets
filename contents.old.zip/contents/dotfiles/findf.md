---
layout: post.njk
title: findf
category: Dotfiles
---

# `findf`

This is a way to find files quickly. 

```sh
$ "findf $FILE_NAME"
```

---
layout: post.njk
title: prune-dirs
category: Dotfiles
---

# `prune-dirs`
Remove empty directories under and including <path>s.

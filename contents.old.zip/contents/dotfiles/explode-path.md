---
layout: post.njk
title: explode-path
category: Dotfiles
---

# `explode-path`
Explode the path to see what is there

---
layout: post.njk
title: testsql
category: Dotfiles
---

# `testsql`
Unused in forever. It's best to delete me.

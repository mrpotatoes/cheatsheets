---
layout: post.njk
title: noargs
category: Dotfiles
---

# `noargs`
Don't run me. This is for the other `bin` files to use if no arguments are provided.

---
layout: post.njk
title: manuals
category: Dotfiles
---

# `manuals`
Use this command to get the manual of one of the custom `bin` scripts I wrote. Opens in the browser.

```sh
manuals mfile
```

---
layout: post.njk
title: git-rename
category: Dotfiles
---

# `git-rename`

Rename the branch you're currently on. It will prompt before renaming and pushing up.

```sh
git-rename
```

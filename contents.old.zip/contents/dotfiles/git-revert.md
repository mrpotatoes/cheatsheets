---
layout: post.njk
title: git-revert
category: Dotfiles
---

# `git-revert`

Completely destroy all the changes on your current branch. Does not `git push` on it's own.

```sh
git-revert
```

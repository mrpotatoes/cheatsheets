NAME
    oo -- Open an application or the current folder that you're in.
SYNOPSIS
    open [--help] application-name
EXAMPLES
    Type the command and a bunch of text with as many spaces as needed
    oo activity monitor
    oo textedit
    oo mail
    
    Or just type the command to open the directory you are already in.
    oo
SEE ALSO
    open
AUTHOR
  Andric Villanueva
COPYRIGHT
  MIT

---
layout: post.njk
title: git-rebuild-source
category: Dotfiles
---

# `git-rebuild-source`
Rebuild the source code. Maintains whatever your `main` branch is named.

Run from the root directory
```sh
git-rebuild-source
```

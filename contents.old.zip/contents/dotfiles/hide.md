---
layout: post.njk
title: hide
category: Dotfiles
---

# `hide`
Don't use me

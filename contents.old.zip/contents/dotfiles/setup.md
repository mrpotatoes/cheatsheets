---
layout: post.njk
title: setup
category: Dotfiles
---

# `setup`

Run the setup program to install things.

So far this hasn't worked for me in awhile. Considering ignoring this, don't know.

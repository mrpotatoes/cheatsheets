---
layout: post.njk
title: argv
category: Dotfiles
---

# `argv`
Don't use me.

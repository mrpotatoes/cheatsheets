---
layout: post.njk
title: search
category: Dotfiles
---

# `search`
An alias for find

```sh
# Example:
$ search .DS_Store
$ search *.module
```

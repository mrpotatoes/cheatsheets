---
layout: post.njk
title: unhide
category: Dotfiles
---

# `unhide`

Hide file by putting a dot in front. Kinda not the best idea but what do I know? I wrote this when I was like 5.

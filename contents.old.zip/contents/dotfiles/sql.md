---
layout: post.njk
title: sql
category: Dotfiles
---

# `sql`

```
Purpose: An easier way to start, stop and restart an apache instance.

Usage: http [command]

Commands:
  st/start            Start the mysql instance.
  sp/stop             Stop the mysql instance.
  rs/restart          restart the mysql instance.
```

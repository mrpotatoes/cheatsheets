---
layout: post.njk
title: sqldown
category: Dotfiles
---

# `sqldown`

```
NAME
    sqldown -- Quickly take a dump of a MySQL Database.
SYNOPSIS
    sqldown [--help] [databse] [file] application-name
EXAMPLES
    sqldown root files files
    sqldown root files files.hey
      
SEE ALSO
    mysqldump
AUTHOR
  Andric Villanueva
COPYRIGHT
  MIT
```

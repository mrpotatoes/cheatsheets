---
layout: post.njk
title: +x
category: Dotfiles
---

# `+x`
`chmod` some stuff 😬

```sh
$ +x <FILE>
```

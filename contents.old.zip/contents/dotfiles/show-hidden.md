---
layout: post.njk
title: show-hidden
category: Dotfiles
---

# `show-hidden`

Not required anymore.

Use this keyboard shortcut instead

```
SHIFT + ⌘ + .
```

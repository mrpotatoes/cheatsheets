---
layout: post.njk
title: mfile
category: Dotfiles
---

# `mfile`
Make a file by extension first.

```sh
mfile md foo
mfile md bar
```
